package src.main;

public class MyAccessControlException extends RuntimeException {
}
