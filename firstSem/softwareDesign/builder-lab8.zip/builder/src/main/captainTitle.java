package src.main;

public class captainTitle implements Title{
    @Override
    public String abbreviation() {
        return "Cap. ";
    }
}
