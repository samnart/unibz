package src.main;

public interface Treatment {
    String announce();

    void setTitle(Title title);
}
