package src.main;

public class DoctorTitle implements Title{

    @Override
    public String abbreviation() {
        return "Dr. ";
    }
}
