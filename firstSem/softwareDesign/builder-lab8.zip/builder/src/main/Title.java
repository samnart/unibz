package src.main;

public interface Title {
    public String abbreviation();
}
