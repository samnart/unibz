package src.main;

public class Untitled implements Title {
    @Override
    public String abbreviation() {
        return "";
    }
}
