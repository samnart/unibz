Builder lab 8

This builder lab has classes for title, treatment and a builder patternfor treatment customization.

Implemented:
AbstractTreatment, ManTreatment, WomanTreatmen, PlaceProxy classes
Title, DocotrTitle, CaptainTitle, TitleComposite interfaces and classes
Treatment and TreatmentBuilder interfaces
Basic functionality for creaeting gender specific treaments, composite titles and proxy treatments

The docotor class is included but not utilized

The TestAbstractTreatment runs and tests all the classes, works fine

Diagram of a handdrawn of the classes is included
