I developed a class called ATM that interacted with other classes.
I used mock objects to similate other classes that interacted with hardware interface.
There were six classes in total.
The ATM class has login(), balance(), withdraw(), deposit() methods and all of them return strings.
There is a printscreen showing all the tests passing.
There is also an AI folder that shows codes i copied from chatgpt.
Finally, I asked for help from friends since I didn't really understand the whole mocking and TDD concept from the beginning, but i understand everything now after completing all the assignments.
