public class Product {
    private double price;

    public Product(double price) {
        this.price = price;
    }
    public double getFinalPrice() {

        return price;
    }
}


