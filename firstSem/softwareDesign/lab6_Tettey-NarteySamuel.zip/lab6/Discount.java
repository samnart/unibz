public interface Discount {
    double discountValue(ShoppingCartItem item);
}

